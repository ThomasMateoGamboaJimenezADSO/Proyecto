para poder usar un servidor local (localhost) necesitamos usar node en esta ocacion usamos la version v20.15.0
para poder ver que vercion de node tenemos en el equipo debemos de usar una terminal cualquiera nos sirve

En esta devemos escribir el comando 'node -v' y precionar 'ENTER' luegoo nos mostrara la version de node instalada en el equipo

En caso tal que la vercion istalada no sea la v20.15.0 debemos hacer uso de nuestro navegador de confiansa y realizar la busqueda de 'node.js' y accedemos al primer resultado esto nos llevara a la pagina de node dentro de la pagina nos dirigiremos al apartado de descargas (Download)

Dentro del apartado de descargas nos dirigiremos al apartado de 'Prebuilt Installer' buscamos la version v20.15.0 y la descagamos e instalamos